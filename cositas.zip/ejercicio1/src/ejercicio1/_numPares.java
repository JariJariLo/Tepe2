package ejercicio1;

public class _numPares<T> implements UnaryPredicate<Integer>{

	@Override
	public boolean test(Integer number) {
		// TODO Auto-generated method stub
		return number%2==0;
	}

}
