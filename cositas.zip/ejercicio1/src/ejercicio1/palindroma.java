package ejercicio1;

public class palindroma<T> implements UnaryPredicate<String>{

	@Override
	public boolean test(String obj) {
		String i=new StringBuilder(obj).reverse().toString();
		return obj.equalsIgnoreCase(i);
	}

	

}
