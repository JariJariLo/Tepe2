package ejercicio1;

import java.util.Collection;
import java.util.Iterator;

public class _generico {

	public static <T> int countIF(Collection<T> c, UnaryPredicate<T> p)
	{
		int count =0;
		/*for each
		 * for (T elem:c)
		 * {
		 * 	if(p.test(elem))
		 *   {
		 * 		cont++;
		 *   }
		 * }
		 * */
		Iterator<T> it=c.iterator();
		while(it.hasNext())
		{
			if(p.test(it.next()))
			{
				count++;
			}
		}
		return count;
	}
}
