package ejercicio1;

import java.util.Arrays;
import java.util.Collection;

public class _main {

	public static void main(String[] args) {

		Collection<String> w= Arrays.asList("radar","apple","level");
		
		Collection<Integer> a = Arrays.asList(1,2,3,4,5);
		//arraylist<Integer> co =new arraylist<>();
		//arr.add();
		UnaryPredicate<String> p =new palindroma();
		UnaryPredicate<Integer> p1 =new _numPares();
		
		System.out.println("Palabras palindromas: " + _generico.countIF(w, p));
		System.out.println("Números Pares: " + _generico.countIF(a, p1));
	}

}
