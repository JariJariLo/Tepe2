package ejercicio1;

public class primos<T> implements UnaryPredicate<Integer>{

	@Override
	public boolean test(Integer obj) {
		// TODO Auto-generated method stub
		if(obj <2) return false;
		for (int i=2;i<=Math.sqrt(obj);i++)
		{
			if(obj%i==0)
			{
				return false;
			}
			
		}
		return true;
	}



}
