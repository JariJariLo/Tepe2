package ejercicio1;

public interface UnaryPredicate <T > {
public boolean test (T obj);
}
