package generic;

public class main {

	public static void main(String[] args) {
		  genericClass<String> gc = new genericClass<>();
	        gc.addElem("Hello");
	        gc.addElem("World");

	        System.out.println(gc.getElem(0)); // Output: Hello
	        System.out.println(gc.getElem(1)); // Output: World
	        System.out.println(gc.getElem(2)); // Output: null
	}

}
