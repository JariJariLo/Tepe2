package generic;

import java.util.Arrays;

public class genericClass<T>{

	private final static int INIT_SIZE = 2;
	private T[] elem;
	private int last;

	public genericClass() 
	{
		last = -1;
		elem = (T[]) new Object[INIT_SIZE];
	}
	public void addElem(T e) {
		if (last == elem.length - 1)
			elem = Arrays.copyOf(elem, elem.length * 2);
		elem[++last] = e;
	}
	public T getElem(int index) {
		if (index > last) return null;
		else return elem[index];
	}


}
