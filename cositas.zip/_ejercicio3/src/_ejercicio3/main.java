package _ejercicio3;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  Integer[] intArray = {1, 2, 3, 4, 5};
	        System.out.println("Antes de intercambiar: " + java.util.Arrays.toString(intArray));
	        _swap.swap(intArray, 1, 3);
	        System.out.println("Después de intercambiar: " + java.util.Arrays.toString(intArray));


	}

}
