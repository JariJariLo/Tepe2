package _ejercicio3;

public class _swap {

	public static <T> void swap(T[] array, int index1, int index2) {
        if (array == null || index1 < 0 || index2 < 0 || index1 >= array.length || index2 >= array.length) {
            throw new IllegalArgumentException("Índices inválidos o array nulo");
        }
        T temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
	}
	
	
}

/*public static <T> void swap(List<T> l, int index1, int index2)
 * T temp= l.get(i);
 * l.set(i,l.get(j));
 * l.set(j,tmp);
 * */
 