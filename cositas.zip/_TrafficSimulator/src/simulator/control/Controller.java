package simulator.control;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import simulator.factories.Factory;
import simulator.model.Event;
import simulator.model.TrafficSimulator;
import simulator.view.MapComponent;

public class Controller {
	 private TrafficSimulator _sim;
	    private Factory<Event> _eventsFactory;

	    public Controller(TrafficSimulator sim, Factory<Event> eventsFactory) {
	        if (sim == null) 
	            throw new IllegalArgumentException("Traffic Simulator can't be null");
	        if (eventsFactory == null)
	            throw new IllegalArgumentException("Events Factory can't be null");

	        this._sim = sim;
	        this._eventsFactory = eventsFactory;
	    }

	    public void loadEvents(InputStream in) {
	        try {
	            // Parse the JSON input stream
	            JSONObject jo = new JSONObject(new JSONTokener(in));
	            JSONArray events = jo.getJSONArray("events");

	            // Iterate through the events array and create events
	            for (int i = 0; i < events.length(); i++) {
	                JSONObject eventJson = events.getJSONObject(i);
	                Event event = _eventsFactory.create_instance(eventJson);
	                _sim.addEvent(event);
	            }
	        } catch (JSONException e) {
	            System.err.println("Error parsing JSON: " + e.getMessage());
	            e.printStackTrace();
	        }
	    }

	    public void run(int n, OutputStream out) {
	        PrintStream p = new PrintStream(out);

	        p.println("{");
	        p.println(" \"states\": [");

	        // Run the simulation for n steps
	        for (int i = 0; i < n - 1; i++) {
	            _sim.advance();
	            p.print(_sim.report());
	            p.println(",");
	        }

	        // Print the final state without a trailing comma
	        if (n > 0) {
	            _sim.advance();
	            p.print(_sim.report());
	        }
	        p.println("]");
	        p.println("}");
	    }

	    public void reset() {
	        _sim.reset();
	    }

		public void addObserver(MapComponent mapComponent) {
			// TODO Auto-generated method stub
			
		}
}
