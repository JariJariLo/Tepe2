package simulator.factories;



import org.json.JSONObject;

import simulator.model.LightSwitchingStrategy;
import simulator.model.MostCrowdedStrategy;

public class MostCrowdedStrategyBuilder extends Builder<LightSwitchingStrategy> {

	

	public MostCrowdedStrategyBuilder() {
		super("most_crowded_lss","Most Crowded");
		// TODO Auto-generated constructor stub
	}

	@Override
	protected LightSwitchingStrategy create_instance(JSONObject data) {
		// TODO Auto-generated method stub
		MostCrowdedStrategy crow;
		if(data.has("timeslot"))
			crow = new MostCrowdedStrategy(data.getInt("timeslot"));
		else
			crow = new MostCrowdedStrategy(1);
		return crow;
	}

}
