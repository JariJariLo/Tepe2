package simulator.factories;

import org.json.JSONObject;

import simulator.model.DequeuingStrategy;
import simulator.model.Event;
import simulator.model.LightSwitchingStrategy;
import simulator.model.NewJunctionEvent;

public class NewJunctionEventBuilder extends Builder<Event>{
	
	private Factory<LightSwitchingStrategy> lssFactory;
	private Factory<DequeuingStrategy> dqsFactory;
	private int time;
	private String id;
	private int x;
	private int y;
	private LightSwitchingStrategy ls;
	private DequeuingStrategy dq;
	
	public NewJunctionEventBuilder(Factory<LightSwitchingStrategy> lssFactory, Factory<DequeuingStrategy> dqsFactory) {
		super("new_junction", "New Junction Event");
		// TODO Auto-generated constructor stub
		if (lssFactory == null || dqsFactory == null) {
            throw new IllegalArgumentException("Factories cannot be null");
        }
        this.lssFactory = lssFactory;
        this.dqsFactory = dqsFactory;
	}

	@Override
	protected Event create_instance(JSONObject data) {
		// TODO Auto-generated method stub
		NewJunctionEvent nJuct;
		this.time = data.getInt("time");
		this.id = data.getString("id");
		this.x = data.getJSONArray("coor").getInt(0);
		this.y = data.getJSONArray("coor").getInt(1);
		this.ls = lssFactory.create_instance(data.getJSONObject("ls_strategy"));
		this.dq = dqsFactory.create_instance(data.getJSONObject("dq_strategy"));
		
		nJuct = new NewJunctionEvent(this.time, this.id, this.ls, this.dq, this.x, this.y);
		
		return nJuct;
    }
	}


