package simulator.model;

public class InterCityRoad extends Road{

	InterCityRoad(String id, Junction srcJunction, Junction destJunc, int maxspeed,  int contLimit,int length,
			Weather weather) {
		super(id, srcJunction, destJunc, maxspeed,  contLimit,length, weather);
		// TODO Auto-generated constructor stub
	}

	@Override
	void reduceTotalContamination() {
		// TODO Auto-generated method stub
		int x = 0;
		Weather tc = this.getWeather();
		if (tc == Weather.SUNNY)
			x = 2;
		else if (tc == Weather.CLOUDY)
			x = 3;
		else if (tc == Weather.RAINY)
			x = 10;
		else if (tc == Weather.WINDY)
			x = 15;
		else 
			x = 20;
		this.setContTotal(((100 - x)*this.getTotalCO2()/ 100));
	}

	@Override
	void updateSpeedLimit() {
		// TODO Auto-generated method stub
		if (getTotalCO2() > getContLimit()) {
			//this._speedLimit = getMaxSpeed() /2;
			this.setSpeedLimit(getMaxSpeed()/2);
		}
		else
			//this._speedLimit = this._maxSpeed;
			this.setSpeedLimit(getMaxSpeed());
	}

	@Override
	int calculateVehicleSpeed(Vehicle v) {
		// TODO Auto-generated method stub
		if (this.getWeather() == Weather.STORM)
			v.setSpeed((int)(getSpeedLimit() * 0.8));
		else
			v.setSpeed(getSpeedLimit());
		return v.getSpeed();
	}

}
