package simulator.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.json.JSONObject;

public class Vehicle extends SimulatedObject{
	private List<Junction> _itinerary;
	private int _maxSpeed;
	private int _currentSpeed;
	private VehicleStatus _status;
	private Road _road;
	private int _location;
	private int _contClass;
	private int _totalCont;
	private int _totalDist;
	private int current_junct;

	/*
location (of type int): the vehicle's position on the road on which it is traveling (the distance from the beginning of the road, i.e., point 0).
	 */
	Vehicle(String id, int maxSpeed, int contClass, List<Junction> itinerary) {
		super(id);
		// TODO complete
		if (maxSpeed <= 0) {
			throw new IllegalArgumentException("max speed must be a positive number");
		}
		else
			this._maxSpeed = maxSpeed;
		if (contClass < 0 || contClass > 10)
			throw new IllegalArgumentException("class must be a number between 0 and 10");
		else 
			this._contClass = contClass;
		if(itinerary.size() < 2)
			throw new IllegalArgumentException("itinerary must be at least 2");
		else 
			this._itinerary = Collections.unmodifiableList(new ArrayList<>(itinerary));
		if(_currentSpeed == 0) 
			this._status = VehicleStatus.PENDING;

		this._location = 0;
		this._currentSpeed = 0;
		this.current_junct= 0;
		this._contClass = contClass;
		this._totalDist = 0;

	}
	@Override
	void advance(int time) {
		// TODO Auto-generated method stub
		if (this._status.equals(VehicleStatus.TRAVELING)){
			int locNew = Math.min(this._location + this._currentSpeed, this._road.getLength());
			int loc = locNew - this._location;
			int c = this._contClass * loc;

			this._totalCont += c;
			this._road.addContamination(c);
			this._totalDist += locNew - this._location;
			this._location = locNew;

			if(locNew == this._road.getLength()){
				this._status = VehicleStatus.WAITING;
				this._currentSpeed = 0;
				this._road.getDestJunct().enter(this);
			}
		}
	}

	@Override
	public JSONObject report() {
		// TODO Auto-generated method stub
		JSONObject obj=new JSONObject();
		obj.put("id",this._id);
		obj.put("speed",this._currentSpeed);
		obj.put("distance",this._totalDist);
		obj.put("co2",this._totalCont);
		obj.put("class",this._contClass);
		obj.put("status",this._status.toString());

		if(!(_status.equals(VehicleStatus.PENDING)||_status.equals(VehicleStatus.ARRIVED)))
		{
			obj.put("road",this._road.getId());
			obj.put("location",getLocation());
		}

		return obj;
	}
	void setSpeed(int s)
	{
		if(this._status != VehicleStatus.TRAVELING) {
			return;
		}
		if(s < 0)
			throw new IllegalArgumentException("speed must be a positive number");  
		if (s <= this._maxSpeed)
			this._currentSpeed= s;
		else
			this._currentSpeed = this._maxSpeed;
	}
	void setContaminationClass(int c)
	{
		if(c <= 0 || c >= 10)
			throw new IllegalArgumentException("class must be a number between 0 and 10"); 
		else {
			this._contClass= c;
		}
	}
	void moveToNextRoad()
	{
		this._location = 0;
		//this._currentSpeed = 0;
		if (!this._status.equals(VehicleStatus.PENDING) && !this._status.equals(VehicleStatus.WAITING))
			throw new IllegalArgumentException("Illegal status");

		if (!this._status.equals(VehicleStatus.PENDING)) {
			this._road.exit(this);
		}
		if(this.current_junct+1 == this._itinerary.size()){
			this._status = VehicleStatus.ARRIVED;
			this._road = null;
		}
		else {
			Junction posAhora = this._itinerary.get(current_junct);
			Junction posQueAvanza = this._itinerary.get(current_junct + 1);

			Road nextRoad = posAhora.roadTo(posQueAvanza);
			nextRoad.enter(this);
			this._road= nextRoad;
			this._status = VehicleStatus.TRAVELING;
			//indice le sumas más uno por si no estas en 0
			this.current_junct++;
		}

	}
	public int getLocation()
	{
		return _location;
	}
	public int getTotalDistance()
	{
		return _totalDist;
	}
	public int getTotalCO2()
	{
		return _totalCont;
	}
	public int getContClass()
	{
		return _contClass;
	}
	public int getSpeed() {
		// TODO Auto-generated method stub
		return _currentSpeed;
	}
	public int getMaxSpeed() {
		return _maxSpeed;
	}
	public VehicleStatus getStatus() {
		// TODO Auto-generated method stub
		return this._status;
	}
	public void setStatus(VehicleStatus estado) {
		this._status = estado;
	}
	public List<Junction> getItinerary() {
		return Collections.unmodifiableList(_itinerary);
	}
	public void setItinerary(List<Junction> itinerary) {
		this._itinerary = itinerary;
	}
	public Road getRoad() {
		return _road;
	}
	public void setRoad(Road road) {
		this._road = road;
	}

}
