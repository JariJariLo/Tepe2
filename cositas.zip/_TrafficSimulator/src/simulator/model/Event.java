package simulator.model;

public abstract class Event implements Comparable<Event> {

	private static long _counter = 0;
	protected int _time;//tiempo en el cual este evento tiene que ser ejecutado 
	protected long _time_stamp;
	Event(int time) {
		  if ( time < 1 )
		      throw new IllegalArgumentException("Invalid time: "+time);
		    else {
		      _time = time;
		      _time_stamp = _counter++;
		    }
		  }


	protected int getTime() {
		return this._time;
	}

	@Override
	public int compareTo(Event o) {
		// TODO complete the method to compare events according to their _time
		
		
		    if (this._time == o._time) {
		        return Long.compare(this._time_stamp, o._time_stamp);
		    }
		    return this._time - o._time;
		}

	

	 abstract void execute(RoadMap map);//el simulador llama a este evento para ejecutar el evento especifico
}
