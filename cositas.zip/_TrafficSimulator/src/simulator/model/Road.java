package simulator.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public abstract class Road extends SimulatedObject{

	private int _length;
	private Junction _srcjunction;
	private Junction _destjunction;
	private int _maxSpeed;
	private int _alarmContEX;
	private int _speedLimit;
	private Weather _condAmb;
	private int contTotal;
	private List<Vehicle> vehicles;
	private static Orden orden;


	Road(String id, Junction srcJunction, Junction destJunc,int maxspeed,int contLimit,int length,
			Weather weather) {
		super(id);
		this.vehicles = new ArrayList<>();


		if (maxspeed <=0)
			throw new IllegalArgumentException( "Max Speed can´t be negative");
		else
			this._maxSpeed = maxspeed;

		if (contLimit < 0)
			throw new IllegalArgumentException( "The contamination limit can´t be negative");
		else
			this._alarmContEX= contLimit;

		if (length <= 0)
			throw new IllegalArgumentException( "The leght can´t be negative");
		else
			this._length = length;
		if (srcJunction == null)
			throw new IllegalArgumentException( "The source road can´t be null");
		else
			this._srcjunction = srcJunction;
		if(destJunc == null)
			throw new IllegalArgumentException( "The destination road can´t be null");
		else
			this._destjunction = destJunc;

		if (weather == null)
			throw new IllegalArgumentException( "The weather can´t be null");
		else
			this._condAmb = weather;

		this.orden = new Orden();
		this._srcjunction.addOutGoingRoad(this);
		this._destjunction.addIncomingRoad(this);
		this._speedLimit = _maxSpeed;
	}

	public class Orden implements Comparator<Vehicle> {

		public Orden(){

		}
		public int compare(Vehicle o1, Vehicle o2) {
			if(o1.getLocation() < o2.getLocation())
			{
				return 1;
			}
			else if(o1.getLocation()==o2.getLocation())
			{
				return 0;
			}
			else{
				return -1;
			}
		}
	}
	void exit(Vehicle v)
	{
		this.vehicles.remove(v);
	}
	void enter(Vehicle v){
		if (v.getSpeed() != 0)
			throw new IllegalArgumentException("Incorrect speed");
		else if (v.getLocation() != 0) {
			throw new IllegalArgumentException("Incorrect location");
		}
		else {
			this.vehicles.add(v);
		}

	}

	void setWeather(Weather w) 
	{
		if (w == null)
			throw new IllegalArgumentException("Road Weather can't be null");
		else
			this._condAmb = w;
	}

	abstract void reduceTotalContamination();

	abstract void updateSpeedLimit();

	abstract int calculateVehicleSpeed(Vehicle v);

	@Override
	void advance(int time) {
		// TODO Auto-generated method stub
		this.reduceTotalContamination();

		this.updateSpeedLimit();

		for(Vehicle v:this.vehicles)
		{
			if (v.getStatus().equals(VehicleStatus.TRAVELING)) {
				v.setSpeed(calculateVehicleSpeed(v));
				v.advance(time);
			}
		}

		//clases anidadas
		
		this.vehicles.sort(orden);
	}
	void addContamination(int c)
	{
		if(c < 0)
			throw new IllegalArgumentException("Road contamination can't be negative");
		else
			this.contTotal += c;
	}
	@Override
	public JSONObject report() {
		// TODO Auto-generated method stub
		JSONObject obj = new JSONObject();
		JSONArray vh=new JSONArray();
		obj.put("id",this._id);
		obj.put("speedlimit",this.getSpeedLimit());
		obj.put("weather",this.getWeather().toString());
		obj.put("co2",this.getTotalCO2());
		obj.put("vehicles", vh);
		for(Vehicle v:vehicles)
		{
			vh.put(v.getId());
		}


		return obj;
	}
	public int getLength() {
		// TODO Auto-generated method stub
		return _length;
	}

	public Junction getDestJunct() {
		// TODO Auto-generated method stub
		return _destjunction;
	}
	public int getContLimit() {
		return _alarmContEX;
	}
	public void setAlarmContEx(int alarmContEx) {
		this._alarmContEX = alarmContEx;
	}
	public Weather getWeather() {
		return _condAmb;
	}
	public void setCondAmb(Weather condAmb) {
		this._condAmb = condAmb;
	}
	public int getTotalCO2() {
		return contTotal;
	}
	public void setContTotal(int contTotal) {
		if(contTotal<0)
			this.contTotal = 0;
		else {
			this.contTotal = contTotal;
		}
	}
	public List<Vehicle> getVehicles() {
		return Collections.unmodifiableList(vehicles);
	}
	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
	public void setLength(int length) {
		this._length = length;
	}
	public Junction getSrcJunct() {
		return _srcjunction;
	}
	public void setSrcJunct(Junction srcJunct) {
		this._srcjunction = srcJunct;
	}
	public int getMaxSpeed() {
		return _maxSpeed;
	}
	public void setMaxSpeed(int maxSpeed) {
		this._maxSpeed = maxSpeed;
	}
	public int getSpeedLimit() {
		return _speedLimit;
	}
	public void setSpeedLimit(int speedLimit) {
		this._speedLimit = speedLimit;
	}

}
