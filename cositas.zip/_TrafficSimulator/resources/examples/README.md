This directory includes some input examples together with their expected output: the output expected for example "exname.json" is in "exname.expout.json". The file db.json includes the number of ticks used to generate each example. Don't modify any of these these files!.


You can use extra.testing.TestExamples to run your assignment on all these examples, and automatically compare the output to the expected one. If you change the place of this directory, you can pass the new path as a command-line argument to extra.testing.TestExamples. This program uses db.json in order to decide which examples to run and for how many ticks.
